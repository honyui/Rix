package rnet

import "Rxin/riface"

//实现router时，先嵌入BaseRouter基类，然后根据需要对这个基类的方法进行重写就好



//这里之所以BaseRouter没有实现
//是因为有Router不希望有PreHandle，PostHandle这两个业务
//所以ROuter全部继承BaseRouter的好处就是，不需要实现PreHandle，Posthandle
type BaseRouter struct {}


//在处理conn业务之前的钩子方法hook
func(br *BaseRouter)PreHandle(request riface.Irequest){}
//在处理conn业务的主方法hook
func(br *BaseRouter)Handle(request riface.Irequest){}
//在处理conn业务之后的钩子方法hook
func(br *BaseRouter)PostHandle(request riface.Irequest){}

