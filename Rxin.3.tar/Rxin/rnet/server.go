package rnet

import (
	"Rxin/riface"
	"fmt"
	"net"
)

//iserver的接口实现，定义一个server的服务器类

type Server struct {
	//服务器的名称
	Name string
	//服务器的ip版本
	IPVersion string
	//服务器绑定的ip
	IP string
	//服务器的端口
	Port int
	//当前的Server添加一个router，server注册的连接对应的处理业务
	Router riface.IRouter
}





//启动服务器
func (s *Server) Start() {

	fmt.Printf("[Start] Server Listenner at IP :%s, Port %d ,is starting\n",s.IP, s.Port)
	go func() {
		//1.获取一个TCP的addr
		addr , err := net.ResolveTCPAddr(s.IPVersion,fmt.Sprintf("%s:%d",s.IP, s.Port))
		if err != nil{
			fmt.Print("resolve tcp addt error :" ,err)
			return
		}

		//2.监听服务器的地址
		lisrenner, err := net.ListenTCP(s.IPVersion,addr)
		if err !=nil {
			fmt.Println("Listen",s.IPVersion,"error",err)
			return

		}
		fmt.Printf("start Rxin server succ, ", s.Name," succ, Listenning...")
		var cid uint32
		cid = 0


		//3.阻塞等待客户端链接，处理客户端链接业务
		for  {
			//如果有客户端链接过来，阻塞会返回
			conn, err := lisrenner.AcceptTCP()
			if err != nil{
				fmt.Println("Accept err",err)
				return
			}
			//将处理连接的业务方法 和 conn 进行绑定 得到我们的链接模块
			dealConn := NewConnection(conn, cid, s.Router)
			cid ++
			//启动当前的链接业务
			go dealConn.Start()
		}

	}()

}
//停止服务器
func (s *Server) Stop() {
	//todo 停止服务
}
//运行服务器
func (s *Server) Server() {
	//启动server服务功能
	s.Start()

	//TODO 做一些启动服务之后的业务
	//阻塞状态
	select {}
}

func(ser *Server)AddRouter(router riface.IRouter){
	ser.Router = router
	fmt.Println("Add Router Succ!!")
}


/*
初始化service模块方法
 */
func NewServer(name string) *Server {
	ser := &Server{
		Name:name,
		IPVersion:"tcp4",
		IP:"0.0.0.0",
		Port:8999,
		Router:nil,
	}
	return ser
}