package riface

/*
路由抽象接口
路由里的数据都
 */

type IRouter interface {
	//在处理conn业务之前的钩子方法hook
	PreHandle(request Irequest)

	//在处理conn业务的主方法hook
	Handle(request Irequest)
	//在处理conn业务之后的钩子方法hook
	PostHandle(request Irequest)
}